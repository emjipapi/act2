<?php

namespace App\Controllers;

use App\Models\UserModel;

class Home extends BaseController
{

    protected $UserModel;
    
    public function __construct(){
        helper(['form', 'url']);
        $this->UserModel = new UserModel();
    }

    public function index()
    {
         $data["users"] = $this->UserModel->getAllData();
        return view('welcome_message', $data);
          print_r($data);
          var_dump($data);
        // return 'ready';
    }
    public function studentForm(){
        return view('studentForm');
    }
    public function studentSave(){
        $firstname = $this->request->getPost('firstname');
        print_r($firstname);
    }
}

?>

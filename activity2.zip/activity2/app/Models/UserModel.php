<?php
namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model {
    protected $table = 'user';
    
    public function getAllData(){
        return $this->findAll();
    }
}

?>
<?php

foreach ($users as $user){
    echo $user['firstname']. ' ' .$user['lastname'];
}
?>